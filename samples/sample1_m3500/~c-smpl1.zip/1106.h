// 1106.h : main header file for the 1106 application
//

#if !defined(AFX_1106_H__2D97FCA7_A93E_46CB_88A3_512F112A3DD6__INCLUDED_)
#define AFX_1106_H__2D97FCA7_A93E_46CB_88A3_512F112A3DD6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMy1106App:
// See 1106.cpp for the implementation of this class
//

class CMy1106App : public CWinApp
{
public:
	CMy1106App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy1106App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMy1106App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_1106_H__2D97FCA7_A93E_46CB_88A3_512F112A3DD6__INCLUDED_)
